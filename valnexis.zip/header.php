<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VALNEXIS ENGINEERING - Smart Engineering. Smart Valves.</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Poppins Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Owl Carousel CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="header-top">
            <div class="container">
                <div class="row align-items-center">
                  
                        <div class="col-md-2">
                                <div class="d-flex align-items-center">
                                    <a href="/website">
                                        <img src="images/logo-icon.png" alt="Valnexis Logo" class="logo_width">
                                    </a>
                                </div>
                        </div>



                        <div class="col-md-10 cutom_top">
                            <div class="row">
                            <div class="col-md-3">
                                <div class="d-flex align-items-center">
                                    <h3 class="mb-0 val_heading">VALNEXIS ENGINEERING</h3>
                                </div>
                            </div>

                            <div class="col-md-9">
                                <div class="header-info">
                                    <p class="mb-0"><i class="fas fa-phone me-2"></i> Call: 090827 83860</p>
                                    <p><i class="fas fa-envelope me-2"></i> Email: sales@valnexis.in</p>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <nav class="navbar bg-light rounded-3 cutom_header">
                                   
                                                <ul class="nav-menu d-flex justify-content-center">
                                                    <li><a href="index.php" <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'class="active"' : ''; ?>>HOME</a></li>
                                                    <li><a href="valnexis.php" <?php echo basename($_SERVER['PHP_SELF']) == 'valnexis.php' ? 'class="active"' : ''; ?>>VALNEXIS</a></li>
                                                    <li><a href="products.php" <?php echo basename($_SERVER['PHP_SELF']) == 'products.php' ? 'class="active"' : ''; ?>>PRODUCTS</a></li>
                                                    <li><a href="services.php" <?php echo basename($_SERVER['PHP_SELF']) == 'services.php' ? 'class="active"' : ''; ?>>SERVICES</a></li>
                                                    <li><a href="contact.php" <?php echo basename($_SERVER['PHP_SELF']) == 'contact.php' ? 'class="active"' : ''; ?>>CONTACT US</a></li>
                                                 </ul>

                                                 <ul class="nav-menu d-flex justify-content-center">
                                                   <li><a href="#" class="brochure-btn">BROCHURE</a></li>
                                                </ul>
                                           
                                </nav>
                            </div>
                        </div>
                        </div>
                   
                    
                   
                </div>
            </div>
        </div>
        
    </header>
